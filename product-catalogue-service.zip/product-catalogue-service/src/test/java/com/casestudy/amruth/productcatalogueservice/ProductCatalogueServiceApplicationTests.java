package com.casestudy.amruth.productcatalogueservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCatalogueServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
