package com.casestudy.amruthvbhat.apiproductcatalogueservice1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiProductCatalogueService1Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiProductCatalogueService1Application.class, args);
	}

}
