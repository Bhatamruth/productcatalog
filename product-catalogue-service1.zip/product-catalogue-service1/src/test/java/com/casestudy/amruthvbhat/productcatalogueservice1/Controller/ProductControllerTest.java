package com.casestudy.amruthvbhat.productcatalogueservice1.Controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.casestudy.amruthvbhat.productcatalogueservice1.Model.Product;
import com.casestudy.amruthvbhat.productcatalogueservice1.Service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;
import static org.mockito.Mockito.when;


@WebMvcTest(ProductController.class)
public class ProductControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ProductService productService;

    @Test
    public void testListProducts() throws Exception {
        // Create a sample list of products for testing
        List<Product> productList = Arrays.asList(
            new Product(),
            new Product()
        );

        // Mock the service to return the sample product list
        when(productService.listAll()).thenReturn(productList);

        // Perform the GET request to /products and verify the response
        mockMvc.perform(MockMvcRequestBuilders.get("/products")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(MockMvcResultMatchers.status().isOk())
            .andExpect(MockMvcResultMatchers.content().json(objectMapper.writeValueAsString(productList)));
    }

    @Test
    public void testGetProductById() throws Exception {
        // Create a sample product
        Product product = new Product(1, "Product 1", 10);

        // Mock the service to return the sample product when the ID is requested
        when(productService.get(1)).thenReturn(product);

        // Perform the GET request to /products/{id} and verify the response
        mockMvc.perform(MockMvcRequestBuilders.get("/products/1")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(MockMvcResultMatchers.status().isOk())
            .andExpect(MockMvcResultMatchers.content().json(objectMapper.writeValueAsString(product)));
    }

    @Test
    public void testGetProductByIdNotFound() throws Exception {
        // Mock the service to throw a NoSuchElementException when the ID is not found
        when(productService.get(1)).thenThrow(NoSuchElementException.class);

        // Perform the GET request to /products/{id} for a non-existent ID and verify the response
        mockMvc.perform(MockMvcRequestBuilders.get("/products/1")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    @Test
    public void testCreateProduct() throws Exception {
    	// Create a sample product
        Product product = new Product(1, "Product 1", 10);

        // Mock the service's behavior when the add method is called
        doNothing().when(productService).getClass();

        // Perform the POST request to /products with a JSON body and verify the response
        mockMvc.perform(MockMvcRequestBuilders.post("/products")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(product)))
            .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    public void testUpdateProduct() throws Exception {
        // Create a sample product
        Product product = new Product(1, "Updated Product", 15);

        // Mock the service to return the product when saved
        when(productService.get(1)).thenReturn(new Product(1, "Product 1", 10));
        

        // Perform the PUT request to /products/{id} with a JSON body and verify the response
        mockMvc.perform(MockMvcRequestBuilders.put("/products/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(product)))
            .andExpect(MockMvcResultMatchers.status().isOk());
    }
    /*
    @Test
public void testUpdateProductNotFound() throws Exception {
        // Mock the service to throw a NoSuchElementException when the ID is not found
        when(productService.get(1)).thenThrow(NoSuchElementException.class);

        // Perform the PUT request to /products/{id} for a non-existent ID and verify the response
        mockMvc.perform(MockMvcRequestBuilders.put("/products/1")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(MockMvcResultMatchers.status().isNotFound());
    }
*/
    @Test
    public void testDeleteProduct() throws Exception {
        // Perform the DELETE request to /products/{id} and verify the response
        mockMvc.perform(MockMvcRequestBuilders.delete("/products/1"))
            .andExpect(MockMvcResultMatchers.status().isOk());
    }
}

//testListProducts tests the list() method.
//testGetProductById tests the get() method when a valid product ID is provided.
//testGetProductByIdNotFound tests the get() method when an invalid product ID is provided.
//testCreateProduct tests the add() method.
//testUpdateProduct tests the update() method when a valid product ID is provided.
//testUpdateProductNotFound tests the update() method when an invalid product ID is provided.
//testDeleteProduct tests the delete() method

